exports.Prefix = `.`;//your prefix for bot
exports.Token = `ODAwNjg1OTQxMTk5MDc3NDI2.YAVu5A.eXFlLrLg0pg4IdnDud3EjRYglHg`;//your token 
exports.Color = `RED`;//color   of embed